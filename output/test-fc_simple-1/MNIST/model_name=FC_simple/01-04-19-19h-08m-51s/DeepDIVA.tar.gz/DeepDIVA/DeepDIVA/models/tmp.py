import torchvision.models as models


models.vgg19_bn()
