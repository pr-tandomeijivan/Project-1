from .bidimensional import Bidimensional

__all__ = ['Bidimensional']
